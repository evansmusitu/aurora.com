from dataclasses import dataclass
import os
from pathlib import Path
from threading import Event
from typing import Mapping

from .cache import EdgeCache
from .management import EdgeManagementServer


@dataclass(frozen=True)
class RuntimeConfig:
    node_id: str
    host: str
    port: int
    cache_path: Path
    airgrid_gateway: bool = False
    lora_relay: bool = False


def runtime_config(env: Mapping[str, str]) -> RuntimeConfig:
    return RuntimeConfig(
        node_id=env.get("MUSITU_EDGE_NODE_ID", "musitu-edge-lab"),
        host=env.get("MUSITU_EDGE_HOST", "0.0.0.0"),
        port=int(env.get("MUSITU_EDGE_PORT", "8080")),
        cache_path=Path(env.get("MUSITU_EDGE_CACHE", "/var/lib/musitu/edge-cache.sqlite3")),
    )


def main() -> None:
    config = runtime_config(os.environ)
    config.cache_path.parent.mkdir(parents=True, exist_ok=True)
    edge_cache = EdgeCache(config.cache_path)
    server = EdgeManagementServer(
        host=config.host,
        port=config.port,
        node_id=config.node_id,
        airgrid_gateway=config.airgrid_gateway,
        lora_relay=config.lora_relay,
    )
    server.start()
    try:
        Event().wait()
    except KeyboardInterrupt:
        pass
    finally:
        server.close()
        edge_cache.close()


if __name__ == "__main__":
    main()
