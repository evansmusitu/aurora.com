from dataclasses import dataclass
from pathlib import Path
import sqlite3


@dataclass(frozen=True)
class CacheEntry:
    key: str
    wire: bytes
    expires_at: int


class EdgeCache:
    def __init__(self, path: str | Path) -> None:
        self._db = sqlite3.connect(path)
        self._db.execute(
            """
            CREATE TABLE IF NOT EXISTS edge_cache (
                cache_key TEXT PRIMARY KEY,
                wire BLOB NOT NULL,
                expires_at INTEGER NOT NULL
            )
            """
        )
        self._db.commit()

    def put(self, key: str, wire: bytes, *, expires_at: int) -> None:
        self._db.execute(
            """
            INSERT INTO edge_cache(cache_key, wire, expires_at)
            VALUES (?, ?, ?)
            ON CONFLICT(cache_key) DO UPDATE SET
                wire = excluded.wire,
                expires_at = excluded.expires_at
            """,
            (key, wire, expires_at),
        )
        self._db.commit()

    def get(self, key: str, *, now: int) -> CacheEntry | None:
        row = self._db.execute(
            "SELECT cache_key, wire, expires_at FROM edge_cache WHERE cache_key = ?",
            (key,),
        ).fetchone()
        if row is None:
            return None
        if row[2] <= now:
            self._db.execute("DELETE FROM edge_cache WHERE cache_key = ?", (key,))
            self._db.commit()
            return None
        return CacheEntry(key=row[0], wire=bytes(row[1]), expires_at=row[2])

    def close(self) -> None:
        self._db.close()
