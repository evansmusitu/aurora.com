from dataclasses import dataclass
import json
from pathlib import Path
import subprocess
from typing import Protocol

from .cache import EdgeCache


@dataclass(frozen=True)
class AirGridPeer:
    peer_id: str
    addresses: tuple[str, ...]


class AirGridSender(Protocol):
    def send(self, peer: AirGridPeer, payload: bytes) -> None:
        ...


@dataclass(frozen=True)
class GatewayDelivery:
    delivered: bool
    reason: str


@dataclass(frozen=True)
class AirGridBridgeEvidence:
    peer_id: str
    security_protocol: str
    transport: str


class AirGridSendError(RuntimeError):
    pass


class Libp2pCliSender:
    def __init__(self, command: str | Path, *, timeout: float = 20) -> None:
        self._command = str(command)
        self._timeout = timeout
        self.last_evidence: AirGridBridgeEvidence | None = None

    def send(self, peer: AirGridPeer, payload: bytes) -> None:
        argv = [self._command, "send", "--peer-id", peer.peer_id]
        for address in peer.addresses:
            argv.extend(["--address", address])
        try:
            completed = subprocess.run(
                argv,
                input=payload,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=self._timeout,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise AirGridSendError("AirGrid bridge unavailable") from exc
        if completed.returncode != 0:
            raise AirGridSendError("AirGrid bridge unavailable")
        try:
            raw = json.loads(completed.stdout.decode("utf-8"))
            evidence = AirGridBridgeEvidence(
                peer_id=str(raw["peerId"]),
                security_protocol=str(raw["securityProtocol"]),
                transport=str(raw["transport"]),
            )
        except (UnicodeDecodeError, json.JSONDecodeError, KeyError, TypeError) as exc:
            raise AirGridSendError("AirGrid bridge returned invalid evidence") from exc
        if evidence.peer_id != peer.peer_id:
            raise AirGridSendError("AirGrid bridge peer mismatch")
        if not evidence.security_protocol or evidence.security_protocol == "/plaintext/2.0.0":
            raise AirGridSendError("AirGrid bridge did not prove encrypted transport")
        if not evidence.transport:
            raise AirGridSendError("AirGrid bridge transport evidence missing")
        self.last_evidence = evidence


class AirGridGateway:
    def __init__(self, cache: EdgeCache, sender: AirGridSender) -> None:
        self._cache = cache
        self._sender = sender

    def forward_cached(self, key: str, peer: AirGridPeer, *, now: int) -> GatewayDelivery:
        entry = self._cache.get(key, now=now)
        if entry is None:
            return GatewayDelivery(False, "cache_miss")
        self._sender.send(peer, entry.wire)
        return GatewayDelivery(True, "forwarded")
