from collections.abc import Callable


class LoRaRelayUnavailable(RuntimeError):
    pass


class OptionalLoRaRelay:
    def __init__(self, sender: Callable[[bytes], None] | None = None) -> None:
        self._sender = sender

    @property
    def enabled(self) -> bool:
        return self._sender is not None

    def send(self, payload: bytes) -> None:
        if self._sender is None:
            raise LoRaRelayUnavailable("LoRa relay is not configured")
        self._sender(payload)
