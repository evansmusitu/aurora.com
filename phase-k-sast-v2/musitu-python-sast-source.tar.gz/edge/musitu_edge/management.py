import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread


class EdgeManagementServer:
    def __init__(
        self,
        *,
        host: str,
        port: int,
        node_id: str,
        airgrid_gateway: bool,
        lora_relay: bool,
    ) -> None:
        status_payload = {
            "service": "MUSITU Edge",
            "nodeId": node_id,
            "status": "healthy",
            "capabilities": {
                "airgridGateway": airgrid_gateway,
                "loraRelay": lora_relay,
            },
            "management": "read-only-lab",
            "cache": {"status": "ready"},
        }

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802
                if self.path == "/healthz":
                    self._write_json(200, {"status": "ok", "service": "MUSITU Edge"})
                    return
                if self.path == "/v1/edge/status":
                    self._write_json(200, status_payload)
                    return
                self._write_json(404, {"error": "not_found"})

            def _write_json(self, status: int, payload: dict) -> None:
                body = json.dumps(payload, sort_keys=True).encode("utf-8")
                self.send_response(status)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, format: str, *args) -> None:  # noqa: A003
                return

        self._server = ThreadingHTTPServer((host, port), Handler)
        self._thread: Thread | None = None

    @property
    def url(self) -> str:
        host, port = self._server.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> None:
        self._thread = Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def close(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=2)
