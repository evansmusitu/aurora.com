from __future__ import annotations

import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from musitu_zerosim.providers import DemoZeroSimProvider
from musitu_zerosim.service import ZeroSimLabService


class _InactiveProvider:
    def activate(self, activation_code: str) -> dict:
        raise RuntimeError("ZeroSIM provider not configured")


def _build_service() -> ZeroSimLabService:
    db_path = Path(os.getenv("MUSITU_ZEROSIM_DB", "/tmp/musitu-zerosim.sqlite3"))
    provider_kind = os.getenv("MUSITU_ZEROSIM_PROVIDER", "disabled")
    provider = DemoZeroSimProvider() if provider_kind == "demo" else _InactiveProvider()
    return ZeroSimLabService(db_path, provider)


SERVICE = _build_service()
APP_ROOT = Path(__file__).resolve().parents[1]


class Handler(BaseHTTPRequestHandler):
    service = SERVICE

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, sort_keys=True).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_bytes(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):  # noqa: N802
        if self.path == "/":
            self._send_bytes(200, (APP_ROOT / "index.html").read_bytes(), "text/html; charset=utf-8")
            return
        if self.path == "/app.js":
            self._send_bytes(200, (APP_ROOT / "app.js").read_bytes(), "text/javascript; charset=utf-8")
            return
        if self.path == "/healthz":
            self._send_json(200, {"service": "musitu-mobile", "status": "ok"})
            return
        if self.path.startswith("/v1/zerosim/profiles"):
            from urllib.parse import parse_qs, urlparse

            query = parse_qs(urlparse(self.path).query)
            device_id = (query.get("device_id") or [""])[0]
            if not device_id:
                self._send_json(400, {"error": "device_id_required"})
                return
            self._send_json(200, {"profiles": self.service.list_profiles(device_id)})
            return
        self._send_json(404, {"error": "not_found"})

    def do_POST(self):  # noqa: N802
        if self.path == "/v1/onboarding":
            length = int(self.headers.get("Content-Length", "0"))
            try:
                payload = json.loads(self.rfile.read(length) or b"{}")
            except json.JSONDecodeError:
                self._send_json(400, {"error": "invalid_json"})
                return
            device_id = payload.get("device_id")
            if not isinstance(device_id, str) or not device_id.strip():
                self._send_json(400, {"error": "device_id_required"})
                return
            self._send_json(200, {"device_id": device_id, "profiles": self.service.list_profiles(device_id)})
            return
        if self.path == "/v1/zerosim/activate":
            length = int(self.headers.get("Content-Length", "0"))
            try:
                payload = json.loads(self.rfile.read(length) or b"{}")
            except json.JSONDecodeError:
                self._send_json(400, {"error": "invalid_json"})
                return
            device_id = payload.get("device_id")
            activation_code = payload.get("activation_code")
            if not isinstance(device_id, str) or not device_id.strip():
                self._send_json(400, {"error": "device_id_required"})
                return
            if not isinstance(activation_code, str) or not activation_code.strip():
                self._send_json(400, {"error": "activation_code_required"})
                return
            try:
                profile = self.service.activate(device_id, activation_code)
            except Exception as exc:
                self._send_json(503, {"error": "zerosim_lab_unavailable"})
                return
            self._send_json(200, {"profile": profile})
            return
        self._send_json(404, {"error": "not_found"})

    def log_message(self, fmt, *args):
        pass


def main() -> None:
    host = os.getenv("MUSITU_MOBILE_HOST", "127.0.0.1")
    port = int(os.getenv("MUSITU_MOBILE_PORT", "8782"))
    ThreadingHTTPServer((host, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
