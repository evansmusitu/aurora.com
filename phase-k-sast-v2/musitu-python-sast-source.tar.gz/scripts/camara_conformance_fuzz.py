#!/usr/bin/env python3
from __future__ import annotations

import argparse
import http.client
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / "services" / "network-api"
PORT = 18891
HOST = "127.0.0.1"
PATH = "/device-reachability-status/v1/retrieve"

INVALID = {
    "status": 400,
    "code": "INVALID_ARGUMENT",
    "message": "Client specified an invalid argument, request body or query param.",
}


def request_raw(body: bytes, correlator: str) -> tuple[int, dict, str | None]:
    conn = http.client.HTTPConnection(HOST, PORT, timeout=2)
    conn.request(
        "POST",
        PATH,
        body=body,
        headers={
            "Content-Type": "application/json",
            "Content-Length": str(len(body)),
            "x-correlator": correlator,
        },
    )
    response = conn.getresponse()
    raw = response.read()
    echoed = response.getheader("x-correlator")
    conn.close()
    return response.status, json.loads(raw), echoed


def health_ok() -> bool:
    try:
        with urllib.request.urlopen(f"http://{HOST}:{PORT}/healthz", timeout=1) as response:
            return response.status == 200 and json.load(response).get("status") == "ok"
    except Exception:
        return False


def run() -> dict:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PKG)
    env["MUSITU_STATE_PROVIDER"] = "fixture"
    env["MUSITU_STATE_FIXTURE"] = str(ROOT / "tests" / "fixtures" / "network_snapshot.json")
    env["MUSITU_CAMARA_DEVICE_MAP"] = str(ROOT / "tests" / "fixtures" / "camara_device_map.json")
    env["MUSITU_CONTROL_PORT"] = str(PORT)

    proc = subprocess.Popen(
        [sys.executable, "-m", "musitu_control.server"],
        cwd=ROOT,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        deadline = time.time() + 5
        while time.time() < deadline:
            if health_ok():
                break
            time.sleep(0.05)
        else:
            raise RuntimeError("CAMARA fuzz target did not start")

        cases = [
            ("malformed_json", b"{not-json", 400, "INVALID_ARGUMENT"),
            ("invalid_utf8", b'{"device":"\xff"}', 400, "INVALID_ARGUMENT"),
            ("top_level_array", b"[]", 400, "INVALID_ARGUMENT"),
            ("top_level_string", b'"device"', 400, "INVALID_ARGUMENT"),
            ("device_string", json.dumps({"device": "phone"}).encode(), 400, "INVALID_ARGUMENT"),
            ("phone_array", json.dumps({"device": {"phoneNumber": ["+263700000001"]}}).encode(), 400, "INVALID_ARGUMENT"),
            ("phone_number", json.dumps({"device": {"phoneNumber": 263700000001}}).encode(), 400, "INVALID_ARGUMENT"),
            ("missing_device", b"{}", 422, "MISSING_IDENTIFIER"),
            ("unsupported_identifier", json.dumps({"device": {"ipv6Address": "2001:db8::1"}}).encode(), 422, "UNSUPPORTED_IDENTIFIER"),
            ("unknown_phone", json.dumps({"device": {"phoneNumber": "+263700009999"}}).encode(), 404, "IDENTIFIER_NOT_FOUND"),
            ("valid_reachable", json.dumps({"device": {"phoneNumber": "+263700000001"}}).encode(), 200, None),
        ]

        results = []
        failures = []
        healthy_after_each = True
        for index, (name, body, expected_status, expected_code) in enumerate(cases, start=1):
            correlator = f"musitu-fuzz-{index:02d}-{name}"
            try:
                status, payload, echoed = request_raw(body, correlator)
                healthy = health_ok()
                healthy_after_each = healthy_after_each and healthy
                ok = status == expected_status and echoed == correlator and healthy
                if expected_code is not None:
                    ok = ok and payload.get("code") == expected_code
                else:
                    ok = ok and payload.get("reachable") is True
                if not ok:
                    failures.append(name)
                results.append(
                    {
                        "name": name,
                        "status": status,
                        "code": payload.get("code"),
                        "correlator_echoed": echoed == correlator,
                        "server_healthy_after": healthy,
                        "pass": ok,
                    }
                )
            except Exception as exc:
                healthy = health_ok()
                healthy_after_each = healthy_after_each and healthy
                failures.append(name)
                results.append(
                    {
                        "name": name,
                        "pass": False,
                        "exception": type(exc).__name__,
                        "server_healthy_after": healthy,
                    }
                )

        return {
            "schema_version": 1,
            "status": "pass" if not failures else "fail",
            "case_count": len(cases),
            "failed_cases": failures,
            "server_healthy_after_each_case": healthy_after_each,
            "claim_boundary": "deterministic_lab_protocol_fuzz_not_full_camara_conformance",
            "results": results,
        }
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    report = run()
    print(json.dumps(report, sort_keys=True, indent=None if args.json else 2))
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
