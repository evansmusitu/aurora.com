#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / "services" / "network-api"
HOST = "127.0.0.1"
PORT = 18892
P95_LIMIT_MS = 500.0


def one_request(path: str) -> tuple[bool, float]:
    start = time.perf_counter()
    ok = False
    try:
        with urllib.request.urlopen(f"http://{HOST}:{PORT}{path}", timeout=2) as response:
            raw = response.read()
            payload = json.loads(raw)
            if path == "/healthz":
                ok = response.status == 200 and payload.get("status") == "ok"
            elif path == "/v1/network/state":
                ok = response.status == 200 and isinstance(payload.get("subscribers"), list) and isinstance(payload.get("sessions"), list)
    except Exception:
        ok = False
    elapsed_ms = (time.perf_counter() - start) * 1000.0
    return ok, elapsed_ms


def endpoint_probe(path: str, requests: int, concurrency: int) -> dict:
    batch_start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        results = list(pool.map(lambda _: one_request(path), range(requests)))
    elapsed = time.perf_counter() - batch_start
    latencies = sorted(duration for _, duration in results)
    successes = sum(1 for ok, _ in results if ok)
    errors = requests - successes
    p95_index = max(0, min(len(latencies) - 1, (95 * len(latencies) + 99) // 100 - 1))
    p95 = latencies[p95_index] if latencies else 0.0
    return {
        "request_count": requests,
        "success_count": successes,
        "error_count": errors,
        "error_rate": errors / requests if requests else 0.0,
        "p50_ms": round(latencies[len(latencies) // 2], 3) if latencies else 0.0,
        "p95_ms": round(p95, 3),
        "max_ms": round(latencies[-1], 3) if latencies else 0.0,
        "throughput_rps": round(requests / elapsed, 3) if elapsed > 0 else 0.0,
        "thresholds": {"max_error_rate": 0.0, "max_p95_ms": P95_LIMIT_MS},
        "pass": errors == 0 and p95 <= P95_LIMIT_MS,
    }


def health_ready() -> bool:
    try:
        with urllib.request.urlopen(f"http://{HOST}:{PORT}/healthz", timeout=1) as response:
            return response.status == 200 and json.load(response).get("status") == "ok"
    except Exception:
        return False


def run(requests: int, concurrency: int) -> dict:
    if requests <= 0 or concurrency <= 0:
        raise ValueError("requests and concurrency must be positive")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(PKG)
    env["MUSITU_STATE_PROVIDER"] = "fixture"
    env["MUSITU_STATE_FIXTURE"] = str(ROOT / "tests" / "fixtures" / "network_snapshot.json")
    env["MUSITU_CONTROL_PORT"] = str(PORT)
    proc = subprocess.Popen(
        [sys.executable, "-m", "musitu_control.server"],
        cwd=ROOT,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        deadline = time.time() + 5
        while time.time() < deadline:
            if health_ready():
                break
            time.sleep(0.05)
        else:
            raise RuntimeError("reliability target did not start")

        endpoints = {
            path: endpoint_probe(path, requests, concurrency)
            for path in ("/healthz", "/v1/network/state")
        }
        status = "pass" if all(item["pass"] for item in endpoints.values()) else "fail"
        return {
            "schema_version": 1,
            "status": status,
            "requests_per_endpoint": requests,
            "concurrency": concurrency,
            "endpoints": endpoints,
            "claim_boundary": "local_lab_baseline_not_reliability_load_certification",
        }
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--requests", type=int, default=500)
    parser.add_argument("--concurrency", type=int, default=20)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        payload = run(args.requests, args.concurrency)
    except Exception as exc:
        payload = {
            "schema_version": 1,
            "status": "fail",
            "error": f"{type(exc).__name__}: {exc}",
            "requests_per_endpoint": args.requests,
            "concurrency": args.concurrency,
            "endpoints": {},
            "claim_boundary": "local_lab_baseline_not_reliability_load_certification",
        }
    rendered = json.dumps(payload, sort_keys=True, indent=None if args.json else 2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if payload["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
